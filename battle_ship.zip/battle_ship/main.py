import pygame
import battleship_pac.Battle_menu as menu
import battleship_pac.gameboard as game
import battleship_pac.battleshipSultan as sult
import battleship_pac.completeReq as req
import battleship_pac.Pause_Menu_2 as pase
import battleship_pac.text as txt

menu.menu_screen()
